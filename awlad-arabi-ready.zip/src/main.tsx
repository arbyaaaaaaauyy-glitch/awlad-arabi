import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  ShoppingCart, Search, Plus, Minus, Trash2, Phone, MessageCircle,
  MapPin, User, ShieldCheck, LogOut, Package, Check, X, Settings,
  Truck, ChevronLeft, Menu, Home, Edit2, Save, Eye, EyeOff
} from 'lucide-react';
import './index.css';

type CategoryId = 'beef' | 'lamb' | 'poultry';
type Status = 'sent' | 'confirmed' | 'delivered' | 'cancelled';

type Product = {
  id: string; name: string; category: CategoryId; price: number; unit: string;
  desc: string; image: string; available: boolean;
};

type CartItem = { id: string; name: string; price: number; unit: string; qty: number };
type Order = {
  id: string; items: CartItem[]; subtotal: number; deliveryFee: number; total: number;
  customerName: string; customerPhone: string; address: string; notes: string;
  payment: 'cash'; status: Status; date: string;
};

const OWNER_EMAIL = 'aarby243@gmail.com';
const WA = '201289774726';
const DELIVERY = 30;
const FREE_AT = 1000;

const products0: Product[] = [
  ['beef-tripe','كرشة بلدي','beef',150,'منظفة ومجهزة جاهزة للطبخ','/images/beef-tripe.svg'],
  ['beef-lung','فشة بلدي','beef',120,'طازجة ونضيفة يومياً','/images/beef-lung.svg'],
  ['beef-mmbar','ممبار بلدي','beef',180,'منظف وجاهز للحشو','/images/beef-mmbar.svg'],
  ['beef-trotters','كوارع بلدي','beef',160,'مثالية للفتة والطبيخ','/images/beef-trotters.svg'],
  ['beef-head','لحمة راس بلدي','beef',200,'طازجة ومقطعة جاهزة','/images/beef-head.svg'],
  ['beef-stew','لحمة بقري استيك','beef',380,'مكعبات طازجة للطبيخ والسلق','/images/beef-stew.svg'],
  ['beef-mince','مفروم بقري بلدي','beef',400,'فرم طازج يومي — نسبة دهن مضبوطة','/images/beef-mince.svg'],
  ['beef-liver','كبدة بقري بلدي','beef',360,'طازجة ومضمونة','/images/beef-liver.svg'],
  ['beef-kofta','كفتة بقري','beef',390,'متبلة وجاهزة للشوي','/images/beef-kofta.svg'],
  ['beef-shawarma','لحمة شاورما بقري','beef',420,'شرائح رفيعة جاهزة للتسوية','/images/beef-shawarma.svg'],
  ['lamb-leg','فخدة ضاني','lamb',520,'فخدة طازجة للفرن والشوي','/images/lamb-leg.svg'],
  ['lamb-chops','ريش ضاني','lamb',540,'ريش طازجة للشوي','/images/lamb-chops.svg'],
  ['lamb-shoulder','كتف ضاني','lamb',480,'كتف طازج للفتة والطبيخ','/images/lamb-shoulder.svg'],
  ['goat-meat','لحم جديان بلدي','lamb',460,'لحم جدي طازج بلدي','/images/goat-meat.svg'],
  ['chicken-thighs','أوراك دجاج','poultry',130,'أوراك طازجة','/images/chicken-thighs.svg'],
  ['chicken-breast','صدور دجاج بانيه','poultry',235,'فيليه صدر طازج','/images/chicken-breast.svg'],
  ['chicken-whole','فرخة بلدي كاملة','poultry',145,'فرخة بلدي طازجة كاملة','/images/chicken-whole.svg'],
].map(([id,name,category,price,desc,image]) => ({
  id: id as string, name: name as string, category: category as CategoryId,
  price: price as number, unit: 'كجم', desc: desc as string, image: image as string, available: true
}));

const money = (n:number) => `${n.toLocaleString('ar-EG')} ج`;
const load = <T,>(key:string, fallback:T):T => { try { const x=localStorage.getItem(key); return x?JSON.parse(x):fallback; } catch { return fallback; } };
const save = (key:string, value:unknown) => { try { localStorage.setItem(key, JSON.stringify(value)); } catch {} };

function App() {
  const [products,setProducts] = useState<Product[]>(() => load('awlad-products', products0));
  const [cart,setCart] = useState<CartItem[]>(() => load('awlad-cart', []));
  const [orders,setOrders] = useState<Order[]>(() => load('awlad-orders', []));
  const [view,setView] = useState<'shop'|'admin'>('shop');
  const [cat,setCat] = useState<CategoryId|'all'>('all');
  const [search,setSearch] = useState('');
  const [cartOpen,setCartOpen] = useState(false);
  const [checkout,setCheckout] = useState(false);
  const [adminLogin,setAdminLogin] = useState(false);
  const [email,setEmail] = useState('');
  const [admin,setAdmin] = useState(false);
  const [menu,setMenu] = useState(false);
  const [notice,setNotice] = useState('');

  const filtered = useMemo(() => products.filter(p => p.available && (cat==='all'||p.category===cat) && p.name.includes(search)), [products,cat,search]);
  const subtotal = cart.reduce((s,x)=>s+x.price*x.qty,0);
  const delivery = subtotal===0 ? 0 : subtotal>=FREE_AT ? 0 : DELIVERY;
  const total = subtotal + delivery;
  const count = cart.reduce((s,x)=>s+x.qty,0);

  const persistProducts=(v:Product[])=>{setProducts(v);save('awlad-products',v)};
  const persistCart=(v:CartItem[])=>{setCart(v);save('awlad-cart',v)};
  const persistOrders=(v:Order[])=>{setOrders(v);save('awlad-orders',v)};

  function add(p:Product) {
    const found=cart.find(x=>x.id===p.id);
    persistCart(found?cart.map(x=>x.id===p.id?{...x,qty:x.qty+1}:x):[...cart,{id:p.id,name:p.name,price:p.price,unit:p.unit,qty:1}]);
    setNotice('تمت إضافة المنتج للسلة');
    setTimeout(()=>setNotice(''),1600);
  }
  function qty(id:string,d:number) { persistCart(cart.map(x=>x.id===id?{...x,qty:x.qty+d}:x).filter(x=>x.qty>0)); }
  function remove(id:string){persistCart(cart.filter(x=>x.id!==id))}
  function login(){
    if(email.trim().toLowerCase()===OWNER_EMAIL){
      setAdmin(true);setAdminLogin(false);setView('admin');setNotice('تم تسجيل دخول صاحب المتجر');
    } else setNotice('الإيميل غير مصرح له بلوحة التحكم');
    setTimeout(()=>setNotice(''),2200);
  }
  function place(data:{name:string,phone:string,address:string,notes:string}){
    const now=new Date();
    const order:Order={id:'ORD-'+Date.now().toString().slice(-7),items:cart,subtotal,deliveryFee:delivery,total,
      customerName:data.name,customerPhone:data.phone,address:data.address,notes:data.notes,payment:'cash',
      status:'sent',date:now.toLocaleString('ar-EG')};
    persistOrders([order,...orders]); persistCart([]); setCheckout(false);setCartOpen(false);
    const lines=order.items.map(x=>`• ${x.name} × ${x.qty} = ${money(x.price*x.qty)}`).join('%0A');
    const msg=`طلب جديد من أولاد عربي%0Aرقم الطلب: ${order.id}%0Aالاسم: ${data.name}%0Aالهاتف: ${data.phone}%0Aالعنوان: ${data.address}%0A%0A${lines}%0A%0Aالإجمالي: ${money(order.total)}`;
    window.open(`https://wa.me/${WA}?text=${msg}`,'_blank');
  }

  if(view==='admin' && admin) return <Admin products={products} setProducts={persistProducts} orders={orders} setOrders={persistOrders} onBack={()=>setView('shop')} onLogout={()=>{setAdmin(false);setView('shop')}} />;

  return <div className="min-h-screen">
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-red-100">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between gap-3">
        <button onClick={()=>setView('shop')} className="flex items-center gap-2">
          <div className="w-11 h-11 rounded-xl bg-red-800 text-white flex items-center justify-center font-black">ع</div>
          <div className="text-right"><b className="block text-red-900">أولاد عربي</b><small className="text-stone-500">لبيع اللحوم</small></div>
        </button>
        <div className="hidden md:flex flex-1 max-w-md relative">
          <Search className="absolute right-3 top-2.5 text-stone-400" size={18}/>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="ابحث عن المنتج..." className="w-full rounded-xl border border-stone-200 py-2 pr-10 pl-3 outline-none focus:border-red-500"/>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={()=>setCartOpen(true)} className="relative rounded-xl bg-red-800 text-white px-3 py-2 flex items-center gap-2"><ShoppingCart size={19}/><span className="hidden sm:inline">السلة</span>{count>0&&<i className="absolute -top-2 -left-2 bg-amber-400 text-black rounded-full min-w-5 h-5 text-xs flex items-center justify-center not-italic">{count}</i>}</button>
          <button onClick={()=>setMenu(!menu)} className="md:hidden p-2"><Menu/></button>
        </div>
      </div>
      <div className="md:hidden px-4 pb-3 relative"><Search className="absolute right-7 top-2.5 text-stone-400" size={18}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="ابحث..." className="w-full rounded-xl border border-stone-200 py-2 pr-10"/></div>
      {menu&&<div className="md:hidden px-4 pb-3"><button onClick={()=>setAdminLogin(true)} className="w-full py-2 rounded-xl bg-stone-100">دخول صاحب المتجر</button></div>}
    </header>

    <main className="max-w-6xl mx-auto px-4 pb-16">
      <section className="mt-5 rounded-3xl overflow-hidden bg-gradient-to-l from-red-950 via-red-800 to-red-600 text-white grain">
        <div className="p-7 md:p-12 max-w-2xl"><span className="inline-block bg-white/10 rounded-full px-3 py-1 text-sm">🥩 طازج يومياً</span><h1 className="text-3xl md:text-5xl font-black mt-4">أولاد عربي لبيع اللحوم</h1><p className="mt-3 text-white/85">اختار طلبك من اللحوم والدواجن، وحط عنوانك، وهنبعت الطلب مباشرة على واتساب.</p><div className="flex flex-wrap gap-3 mt-6"><a href={`https://wa.me/${WA}`} target="_blank" className="bg-green-500 px-5 py-3 rounded-xl font-bold flex items-center gap-2"><MessageCircle size={20}/> واتساب</a><a href={`tel:+${WA}`} className="bg-white text-red-900 px-5 py-3 rounded-xl font-bold flex items-center gap-2"><Phone size={19}/> اتصال</a></div></div>
      </section>

      <div className="mt-5 flex gap-2 overflow-x-auto pb-1">
        {[['all','كل المنتجات'],['beef','لحوم بقري'],['lamb','لحوم ضاني وجديان'],['poultry','دواجن']].map(([id,label])=><button key={id} onClick={()=>setCat(id as any)} className={`whitespace-nowrap px-4 py-2 rounded-full font-bold ${cat===id?'bg-red-800 text-white':'bg-white border border-red-100'}`}>{label}</button>)}
      </div>

      <div className="mt-6 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-5">
        {filtered.map((p,i)=><ProductCard key={p.id} p={p} i={i} add={add} />)}
      </div>
      {filtered.length===0&&<div className="text-center py-16 text-stone-500">مفيش منتجات مطابقة للبحث.</div>}

      <section className="mt-10 grid md:grid-cols-3 gap-3">
        <Info icon={<Truck/>} title="توصيل" text={`التوصيل ${DELIVERY} ج ومجاني للطلبات فوق ${FREE_AT} ج`}/>
        <Info icon={<ShieldCheck/>} title="طلب آمن" text="بيانات الطلب بتتخزن محلياً على جهازك وبيتم إرسال تفاصيل الطلب لواتساب."/>
        <Info icon={<MessageCircle/>} title="خدمة سريعة" text="تقدر تتواصل معنا مباشرة على واتساب."/>
      </section>
    </main>

    <footer className="border-t bg-white"><div className="max-w-6xl mx-auto px-4 py-7 flex flex-col sm:flex-row justify-between gap-3 text-sm text-stone-500"><span>© أولاد عربي</span><button onClick={()=>setAdminLogin(true)} className="hover:text-red-800">لوحة صاحب المتجر</button></div></footer>

    {cartOpen&&<Cart items={cart} subtotal={subtotal} delivery={delivery} total={total} onClose={()=>setCartOpen(false)} qty={qty} remove={remove} onCheckout={()=>setCheckout(true)}/>}
    {checkout&&<Checkout onClose={()=>setCheckout(false)} total={total} onSubmit={place}/>}
    {adminLogin&&<Modal onClose={()=>setAdminLogin(false)} title="دخول صاحب المتجر"><div className="space-y-3"><p className="text-sm text-stone-600">اكتب الإيميل المسموح له بالدخول.</p><input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="البريد الإلكتروني" className="w-full border rounded-xl p-3"/><button onClick={login} className="w-full bg-red-800 text-white rounded-xl py-3 font-bold">دخول</button></div></Modal>}
    {notice&&<div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 bg-stone-900 text-white px-5 py-3 rounded-xl shadow-xl">{notice}</div>}
  </div>;
}

function ProductCard({p,i,add}:{p:Product,i:number,add:(p:Product)=>void}) {
  return <article className="bg-white rounded-2xl overflow-hidden card fade">
    <img src={p.image} alt={p.name} className="w-full aspect-[1.15] object-cover bg-red-50"/>
    <div className="p-3"><h3 className="font-black text-sm md:text-base">{p.name}</h3><p className="text-xs text-stone-500 mt-1 min-h-8">{p.desc}</p><div className="flex items-end justify-between mt-3 gap-2"><div><b className="text-red-800">{money(p.price)}</b><small className="block text-stone-400">/ {p.unit}</small></div><button onClick={()=>add(p)} className="bg-red-800 text-white rounded-xl p-2.5"><Plus size={19}/></button></div></div>
  </article>;
}
function Info({icon,title,text}:{icon:React.ReactNode,title:string,text:string}){return <div className="bg-white rounded-2xl p-5 card"><div className="text-red-800">{icon}</div><b className="block mt-2">{title}</b><p className="text-sm text-stone-500 mt-1">{text}</p></div>}

function Modal({onClose,title,children}:{onClose:()=>void,title:string,children:React.ReactNode}){return <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"><div className="bg-white rounded-2xl w-full max-w-md p-5 relative"><button onClick={onClose} className="absolute left-3 top-3"><X/></button><h2 className="text-xl font-black mb-5">{title}</h2>{children}</div></div>}

function Cart({items,subtotal,delivery,total,onClose,qty,remove,onCheckout}:{items:CartItem[],subtotal:number,delivery:number,total:number,onClose:()=>void,qty:(id:string,d:number)=>void,remove:(id:string)=>void,onCheckout:()=>void}) {
 return <div className="fixed inset-0 z-40 bg-black/50 flex justify-end"><aside className="w-full sm:max-w-md bg-white h-full overflow-auto p-4"><div className="flex justify-between items-center"><h2 className="text-xl font-black flex items-center gap-2"><ShoppingCart/> السلة</h2><button onClick={onClose}><X/></button></div>{items.length===0?<div className="py-20 text-center text-stone-500">السلة فاضية</div>:<><div className="mt-5 space-y-3">{items.map(x=><div key={x.id} className="border rounded-xl p-3 flex gap-3 items-center"><div className="flex-1"><b>{x.name}</b><div className="text-sm text-red-800">{money(x.price)} / {x.unit}</div></div><div className="flex items-center gap-1 border rounded-lg"><button className="p-1.5" onClick={()=>qty(x.id,-1)}><Minus size={15}/></button><span>{x.qty}</span><button className="p-1.5" onClick={()=>qty(x.id,1)}><Plus size={15}/></button></div><button onClick={()=>remove(x.id)} className="text-red-700"><Trash2 size={17}/></button></div>)}</div><div className="border-t mt-5 pt-4 space-y-2"><div className="flex justify-between"><span>المجموع</span><b>{money(subtotal)}</b></div><div className="flex justify-between"><span>التوصيل</span><b>{delivery?money(delivery):'مجاني'}</b></div><div className="flex justify-between text-lg"><span>الإجمالي</span><b className="text-red-800">{money(total)}</b></div><button onClick={onCheckout} className="w-full mt-4 py-3 rounded-xl bg-red-800 text-white font-black">إتمام الطلب</button></div></>}</aside></div>
}

function Checkout({onClose,total,onSubmit}:{onClose:()=>void,total:number,onSubmit:(d:{name:string,phone:string,address:string,notes:string})=>void}) {
 const [d,setD]=useState({name:'',phone:'',address:'',notes:''});
 const change=(k:keyof typeof d)=>(e:React.ChangeEvent<HTMLInputElement|HTMLTextAreaElement>)=>setD({...d,[k]:e.target.value});
 return <Modal onClose={onClose} title="تأكيد الطلب"><div className="space-y-3"><input value={d.name} onChange={change('name')} placeholder="الاسم" className="w-full border rounded-xl p-3"/><input value={d.phone} onChange={change('phone')} placeholder="رقم الهاتف" className="w-full border rounded-xl p-3"/><input value={d.address} onChange={change('address')} placeholder="العنوان بالتفصيل" className="w-full border rounded-xl p-3"/><textarea value={d.notes} onChange={change('notes')} placeholder="ملاحظات (اختياري)" className="w-full border rounded-xl p-3 min-h-24"/><div className="bg-red-50 p-3 rounded-xl">الإجمالي: <b className="text-red-800">{money(total)}</b> — الدفع عند الاستلام</div><button disabled={!d.name||!d.phone||!d.address} onClick={()=>onSubmit(d)} className="w-full py-3 rounded-xl bg-red-800 text-white font-bold disabled:opacity-40">إرسال الطلب على واتساب</button></div></Modal>
}

function Admin({products,setProducts,orders,setOrders,onBack,onLogout}:{products:Product[],setProducts:(p:Product[])=>void,orders:Order[],setOrders:(o:Order[])=>void,onBack:()=>void,onLogout:()=>void}) {
 const [tab,setTab]=useState<'products'|'orders'>('products');
 const [show,setShow]=useState(false);
 const [edit,setEdit]=useState<Product|null>(null);
 const [form,setForm]=useState<Partial<Product>>({});
 const saveProduct=()=>{if(!form.name||!form.price)return; if(edit)setProducts(products.map(p=>p.id===edit.id?{...p,...form,price:Number(form.price)} as Product:p)); else setProducts([...products,{id:'p-'+Date.now(),name:form.name,category:(form.category||'beef') as CategoryId,price:Number(form.price),unit:form.unit||'كجم',desc:form.desc||'',image:form.image||'/images/beef-stew.svg',available:true}]);setShow(false);setEdit(null);setForm({})};
 const statusText=(s:Status)=>({sent:'جديد',confirmed:'مؤكد',delivered:'تم التوصيل',cancelled:'ملغي'}[s]);
 return <div className="min-h-screen bg-stone-50"><header className="bg-red-900 text-white"><div className="max-w-6xl mx-auto px-4 h-16 flex justify-between items-center"><b className="text-lg">لوحة تحكم أولاد عربي</b><div className="flex gap-2"><button onClick={onBack} className="bg-white/10 rounded-lg px-3 py-2">المتجر</button><button onClick={onLogout} className="bg-white/10 rounded-lg px-3 py-2"><LogOut size={17}/></button></div></div></header><main className="max-w-6xl mx-auto p-4"><div className="flex gap-2 mb-5"><button onClick={()=>setTab('products')} className={`px-4 py-2 rounded-xl ${tab==='products'?'bg-red-800 text-white':'bg-white'}`}>المنتجات</button><button onClick={()=>setTab('orders')} className={`px-4 py-2 rounded-xl ${tab==='orders'?'bg-red-800 text-white':'bg-white'}`}>الطلبات ({orders.length})</button></div>{tab==='products'?<><button onClick={()=>{setEdit(null);setForm({});setShow(true)}} className="bg-red-800 text-white px-4 py-2 rounded-xl flex gap-2 items-center"><Plus size={18}/> إضافة منتج</button><div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">{products.map(p=><div className="bg-white rounded-2xl p-3 card flex gap-3" key={p.id}><img src={p.image} className="w-20 h-20 rounded-xl object-cover"/><div className="flex-1"><b>{p.name}</b><div className="text-red-800">{money(p.price)}</div><small className="text-stone-500">{p.available?'متاح':'غير متاح'}</small></div><div className="flex flex-col gap-1"><button onClick={()=>{setEdit(p);setForm(p);setShow(true)}}><Edit2 size={17}/></button><button onClick={()=>setProducts(products.map(x=>x.id===p.id?{...x,available:!x.available}:x))}><EyeOff size={17}/></button><button onClick={()=>setProducts(products.filter(x=>x.id!==p.id))} className="text-red-700"><Trash2 size={17}/></button></div></div>)}</div></>:<div className="space-y-3">{orders.length===0?<div className="bg-white rounded-2xl p-8 text-center">لا توجد طلبات حتى الآن.</div>:orders.map(o=><div key={o.id} className="bg-white rounded-2xl p-4 card"><div className="flex justify-between gap-2"><b>{o.id}</b><b className="text-red-800">{money(o.total)}</b></div><div className="text-sm mt-2">{o.customerName} — {o.customerPhone}</div><div className="text-sm text-stone-500">{o.address}</div><div className="text-sm mt-2">{o.items.map(x=>`${x.name} × ${x.qty}`).join('، ')}</div><select value={o.status} onChange={e=>setOrders(orders.map(x=>x.id===o.id?{...x,status:e.target.value as Status}:x))} className="mt-3 border rounded-lg p-2"><option value="sent">{statusText('sent')}</option><option value="confirmed">{statusText('confirmed')}</option><option value="delivered">{statusText('delivered')}</option><option value="cancelled">{statusText('cancelled')}</option></select></div>)}</div>}{show&&<Modal onClose={()=>setShow(false)} title={edit?'تعديل منتج':'إضافة منتج'}><div className="space-y-3"><input value={String(form.name||'')} onChange={e=>setForm({...form,name:e.target.value})} placeholder="اسم المنتج" className="w-full border rounded-xl p-3"/><input type="number" value={String(form.price||'')} onChange={e=>setForm({...form,price:Number(e.target.value)})} placeholder="السعر" className="w-full border rounded-xl p-3"/><select value={form.category||'beef'} onChange={e=>setForm({...form,category:e.target.value as CategoryId})} className="w-full border rounded-xl p-3"><option value="beef">بقري</option><option value="lamb">ضاني/جدي</option><option value="poultry">دواجن</option></select><input value={String(form.desc||'')} onChange={e=>setForm({...form,desc:e.target.value})} placeholder="الوصف" className="w-full border rounded-xl p-3"/><input value={String(form.image||'')} onChange={e=>setForm({...form,image:e.target.value})} placeholder="/images/اسم-الصورة.svg" className="w-full border rounded-xl p-3"/><button onClick={saveProduct} className="w-full bg-red-800 text-white rounded-xl py-3 font-bold">حفظ</button></div></Modal>}</main></div>
}

if ('serviceWorker' in navigator) window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
createRoot(document.getElementById('root')!).render(<App/>);

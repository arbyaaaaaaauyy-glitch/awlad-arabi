export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        arabic: ['Tahoma', 'Arial', 'sans-serif'],
      },
    },
  },
  plugins: [],
};